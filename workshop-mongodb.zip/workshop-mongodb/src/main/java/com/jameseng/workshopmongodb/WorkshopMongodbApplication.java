package com.jameseng.workshopmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkshopMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkshopMongodbApplication.class, args);
	}

}
