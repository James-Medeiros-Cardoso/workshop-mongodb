package com.jameseng.workshopmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkshopMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
